

const User=require("../model/userSchema");




const StatusCheck=async(req,res,next)=>{
try{
 
  const user=await User.findOne(req.params._id);

if(user.AccountStatus=="active" && user.AutoPoolBasic.status=="active"){
  next()

}

else{
  console.log("LevelIncome not work plz Active")
}
}catch(err){
    res.status(401).send('UnAuthorazied token');
    console.log(err);
}
}

const BronzeStatus=async(req,res,next)=>{
  try{
    const user=await User.findOne(req.params._id)
  if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active" ){
    next()
    console.log("sdgsdjhtsk")
  }
  
  else{
    console.log("LevelIncome not work plz Active")
  }
  }catch(err){
      res.status(401).send('UnAuthorazied token');
      console.log(err);
  }
  }
  const SilverStatus=async(req,res,next)=>{
    try{
      const user=await User.findOne(req.params._id)
    if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
      next()
      console.log("sdgsdjhtsk")
    }
    
    else{
      console.log("LevelIncome not work plz Active")
    }
    }catch(err){
        res.status(401).send('UnAuthorazied token');
        console.log(err);
    }
    }
    const GoldStatus=async(req,res,next)=>{
      try{
        const user=await User.findOne(req.params._id)
      if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
        next()
        console.log("sdgsdjhtsk")
      }
      
      else{
        console.log("LevelIncome not work plz Active")
      }
      }catch(err){
          res.status(401).send('UnAuthorazied token');
          console.log(err);
      }
      }
      const GoldStarStatus=async(req,res,next)=>{
        try{
          const user=await User.findOne(req.params._id)
        if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
          next()
          console.log("sdgsdjhtsk")
        }
        
        else{
          console.log("LevelIncome not work plz Active")
        }
        }catch(err){
            res.status(401).send('UnAuthorazied token');
            console.log(err);
        }
        }
        const PlatinumStatus=async(req,res,next)=>{
          try{
            const user=await User.findOne(req.params._id)
          if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
            next()
            console.log("sdgsdjhtsk")
          }
          
          else{
            console.log("LevelIncome not work plz Active")
          }
          }catch(err){
              res.status(401).send('UnAuthorazied token');
              console.log(err);
          }
          }
          const PearlStatus=async(req,res,next)=>{
            try{
              const user=await User.findOne(req.params._id)
            if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
              next()
              console.log("sdgsdjhtsk")
            }
            
            else{
              console.log("LevelIncome not work plz Active")
            }
            }catch(err){
                res.status(401).send('UnAuthorazied token');
                console.log(err);
            }
            }
            const RubyStatus=async(req,res,next)=>{
              try{
                const user=await User.findOne(req.params._id)
              if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
                next()
                console.log("sdgsdjhtsk")
              }
              
              else{
                console.log("LevelIncome not work plz Active")
              }
              }catch(err){
                  res.status(401).send('UnAuthorazied token');
                  console.log(err);
              }
              }
              const EmeraldStatus=async(req,res,next)=>{
                try{
                  const user=await User.findOne(req.params._id)
                if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
                  next()
                  console.log("sdgsdjhtsk")
                }
                
                else{
                  console.log("LevelIncome not work plz Active")
                }
                }catch(err){
                    res.status(401).send('UnAuthorazied token');
                    console.log(err);
                }
                }
                const DimondStatus=async(req,res,next)=>{
                  try{
                    const user=await User.findOne(req.params._id)
                  if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
                    next()
                    console.log("sdgsdjhtsk")
                  }
                  
                  else{
                    console.log("LevelIncome not work plz Active")
                  }
                  }catch(err){
                      res.status(401).send('UnAuthorazied token');
                      console.log(err);
                  }
                  }
                  const AntimatterStatus=async(req,res,next)=>{
                    try{
                      const user=await User.findOne(req.params._id)
                    if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
                      next()
                      console.log("sdgsdjhtsk")
                    }
                    
                    else{
                      console.log("LevelIncome not work plz Active")
                    }
                    }catch(err){
                        res.status(401).send('UnAuthorazied token');
                        console.log(err);
                    }
                    }
                    const CrownStatus=async(req,res,next)=>{
                      try{
                        const user=await User.findOne(req.params._id)
                      if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
                        next()
                        console.log("sdgsdjhtsk")
                      }
                      
                      else{
                        console.log("LevelIncome not work plz Active")
                      }
                      }catch(err){
                          res.status(401).send('UnAuthorazied token');
                          console.log(err);
                      }
                      }
                      const CFStatus=async(req,res,next)=>{
                        try{
                          const user=await User.findOne(req.params._id)
                        if(user.AutoPoolBasic.status=="active" && user. AutoPoolBronze.status=="active",user.AutoPoolSilver.status=="active" ){
                          next()
                          console.log("sdgsdjhtsk")
                        }
                        
                        else{
                          console.log("LevelIncome not work plz Active")
                        }
                        }catch(err){
                            res.status(401).send('UnAuthorazied token');
                            console.log(err);
                        }
                        }
module.exports={StatusCheck,BronzeStatus,SilverStatus,GoldStatus,GoldStarStatus,PlatinumStatus,PearlStatus,
  RubyStatus,EmeraldStatus,DimondStatus,AntimatterStatus,CrownStatus,CFStatus};